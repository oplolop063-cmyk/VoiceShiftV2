VoiceShift - Android project (WebView wrapper around voiceshift.html)

Option A - Android Studio (easiest)
 1. Install Android Studio. Choose File > Open and select this folder.
 2. Wait for Gradle sync, then Build > Build APK(s).
 3. The APK is in app/build/outputs/apk/debug/app-debug.apk. Copy it to your phone and install it
    (allow "Install unknown apps" when asked).

Option B - GitHub (no install)
 1. Upload this folder to a new GitHub repository.
 2. Open the Actions tab, run "Build APK", then download the VoiceShift-apk artifact.

The web app itself is app/src/main/assets/voiceshift.html. Edit it and rebuild to update the app.
This is a debug-signed APK, fine for personal use. For Play Store release, sign it with your own key.
